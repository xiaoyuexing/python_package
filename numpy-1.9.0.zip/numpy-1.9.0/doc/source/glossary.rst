********
Glossary
********

.. toctree::

.. automodule:: numpy.doc.glossary

Jargon
------

.. automodule:: numpy.doc.jargon
